function [I,phi] = transform[I1,I2]
return [I1+I2,0]
end
