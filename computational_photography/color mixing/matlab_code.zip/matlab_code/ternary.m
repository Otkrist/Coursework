function x=ternary(alpha,a,b)
x=b;
if alpha,
  x=a;
end
end
